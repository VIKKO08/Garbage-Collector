const int pinPotMateriale = A0;
const int pinPotPeso=A1; 
const int pinPotVolume = A2; 
const int pinBtnMetallo = 2; 
const int pinBtPotenziometri= 10;
const int ledPins[] = {3, 4, 5, 6, 7, 8, 9};
void setup() 
{
  Serial.begin(9600);
  pinMode(pinBtnMetallo, INPUT_PULLUP);
  pinMode(pinBtPotenziometri, INPUT_PULLUP);
  for (int i = 0; i < 7; i++) pinMode(ledPins[i], OUTPUT);
}
bool statoPrecedenteBtn = HIGH;
void loop()
 {
  int valMat = analogRead(pinPotMateriale); 
  int valVol = analogRead(pinPotVolume);  
  int valpes= analogRead(pinPotPeso);  
  int btnState = digitalRead(pinBtnMetallo); 
  bool statoAttualeBtn = digitalRead(pinBtPotenziometri);

  String materiale = "";
  int ledIndex = -1;
  if (btnState == LOW) {
    materiale = "METALLO";
    ledIndex = 1; // Pin 4
  } 
  else if (valVol > 150 ) {
    materiale = "INGOMBRANTE";
    ledIndex = 6; // Pin 9
  } 
  
  else 
  {
    if (valMat > 650) 
    {         
      materiale = "VETRO";
      ledIndex = 2; // Pin 5
    } else if (valMat > 500) 
    {
      materiale = "PLASTICA";
      ledIndex = 3; // Pin 6
    } else if (valMat > 350) 
    {
      materiale = "ORGANICO";
      ledIndex = 0; // Pin 3
    } else if (valMat > 150 ) 
    {
      materiale = "INDIFFERENZIATO";
      ledIndex = 5; // Pin 8
    } else {
      materiale = "CARTA";
      ledIndex = 4; // Pin 7
    }
  }
  for (int i = 0; i < 7; i++)
   digitalWrite(ledPins[i], LOW);
  if (ledIndex != -1) 
    digitalWrite(ledPins[ledIndex], HIGH);
  if (statoPrecedenteBtn == HIGH && statoAttualeBtn == LOW) {
    Serial.println(materiale + ";" + String(valpes) + ";" + String(valVol));
  }

  statoPrecedenteBtn = statoAttualeBtn;
}